# Geometry Interaction Knowledge Graph Embedding 

This code is the official PyTorch implementation of Geometry Interaction Knowledge Graph Embeddings.
## Datasets

Download and pre-process the datasets:

```bash
source datasets/download.sh
python datasets/process.py
```

## Usage

To train and evaluate a KG embedding model for the link prediction task, use the run.py script:

```bash
usage: run.py [-h] [--dataset {FB15K,WN,WN18RR,FB237,YAGO3-10}]
              [--model {TransE,CP,MurE,GIE,ComplEx,RotatE}]
              [--regularizer {N3,N2}] [--reg REG]
              [--optimizer {Adagrad,Adam,SGD,SparseAdam,RSGD,RAdam}]
              [--max_epochs MAX_EPOCHS] [--patience PATIENCE] [--valid VALID]
              [--rank RANK] [--batch_size BATCH_SIZE]
              [--neg_sample_size NEG_SAMPLE_SIZE] [--dropout DROPOUT]
              [--init_size INIT_SIZE] [--learning_rate LEARNING_RATE]
              [--gamma GAMMA] [--bias {constant,learn,none}]
              [--dtype {single,double}] [--double_neg] [--debug] [--multi_c]
```


## Examples 
```
CUDA_VISIBLE_DEVICES=4 python3 run.py \
            --dataset WN18RR \
            --model GIE \
            --rank 300 \
            --regularizer N3 \
            --reg 0.0 \
            --optimizer Adam \
            --max_epochs 300 \
            --patience 15 \
            --valid 5 \
            --batch_size 1000 \
            --neg_sample_size 50 \
            --init_size 0.001 \
            --learning_rate 0.001 \
            --gamma 0.0 \
            --bias learn \
            --dtype double \
            --double_neg \
            --multi_c


CUDA_VISIBLE_DEVICES=5 python3 run.py \
            --dataset FB237 \
            --model GIE \
            --rank 300 \
            --regularizer N3 \
            --reg 0.0 \
            --optimizer Adagrad \
            --max_epochs 300 \
            --patience 10 \
            --valid 5 \
            --batch_size 1000 \
            --neg_sample_size 50 \
            --init_size 0.001 \
            --learning_rate 0.05 \
            --gamma 0.0 \
            --bias learn \
            --dtype double \
            --multi_c

CUDA_VISIBLE_DEVICES=4 python3 run.py \
            --dataset YAGO3-10 \
            --model GIE \
            --rank 200 \
            --regularizer N3 \
            --reg 0.0 \
            --optimizer Adam \
            --max_epochs 500 \
            --patience 20 \
            --valid 1 \
            --batch_size 1000 \
            --neg_sample_size 50 \
            --init_size 0.001 \
            --learning_rate 0.0005 \
            --gamma 0.0 \
            --bias learn \
            --dtype double \
            --multi_c
```

