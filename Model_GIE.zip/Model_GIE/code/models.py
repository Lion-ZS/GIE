from abc import ABC, abstractmethod
from typing import Tuple, List, Dict
import torch.nn.functional as F
import torch
from torch import nn
import numpy as np
from tqdm import tqdm
from euclidean import givens_rotations, givens_reflection
from hyperbolic import mobius_add, expmap0, project, hyp_distance_multi_c,logmap0,multi_Mx,multi_mx


class KBCModel(nn.Module, ABC):
    def get_ranking(
            self, queries: torch.Tensor,
            filters: Dict[Tuple[int, int], List[int]],
            batch_size: int = 1000, chunk_size: int = -1
    ):
        ranks = torch.ones(len(queries))
        with tqdm(total=queries.shape[0], unit='ex') as bar:
            bar.set_description(f'Evaluation')
            with torch.no_grad():
                b_begin = 0
                while b_begin < len(queries):
                    these_queries = queries[b_begin:b_begin + batch_size]
                    target_idxs = these_queries[:, 2].cpu().tolist()
                    scores, _ = self.forward(these_queries)
                    targets = torch.stack([scores[row, col] for row, col in enumerate(target_idxs)]).unsqueeze(-1)

                    for i, query in enumerate(these_queries):
                        filter_out = filters[(query[0].item(), query[1].item())]
                        filter_out += [queries[b_begin + i, 2].item()]   
                        scores[i, torch.LongTensor(filter_out)] = -1e6
                    ranks[b_begin:b_begin + batch_size] += torch.sum(
                        (scores >= targets).float(), dim=1
                    ).cpu()
                    b_begin += batch_size
                    bar.update(batch_size)
        return ranks


class KG_Model(KBCModel): 
    def __init__(
            self, sizes: Tuple[int, int, int], rank: int,
            init_size: float = 1e-3
    ):
        super(KG_Model, self).__init__()
        self.sizes = sizes
        self.rank = rank
        
        self.context_vec = nn.Embedding(self.sizes[1], self.rank)
        self.context_vec.weight.data = 0.01* torch.randn((self.sizes[1], self.rank))
        self.act = nn.Softmax(dim=1)
        self.scale = torch.Tensor([1. / np.sqrt(self.rank)]).cuda()

        c_init = torch.ones((self.sizes[1], 1))*1.0
        self.c = nn.Parameter(c_init, requires_grad=True)
        self.embeddings = nn.ModuleList([
            nn.Embedding(s, rank, sparse=True)
            for s in sizes[:3]
        ])

        self.embeddings1 = nn.ModuleList([
            nn.Embedding(s, 4*rank, sparse=True)
            for s in sizes[:3]
        ])

        self.embeddings2 = nn.ModuleList([
            nn.Embedding(s, rank, sparse=True)
            for s in sizes[:3]
        ])

        self.embeddings3 = nn.ModuleList([
            nn.Embedding(s, rank, sparse=True)
            for s in sizes[:3]
            ])
        self.embeddings_c = nn.ModuleList([
            nn.Embedding(s, rank, sparse=True)
            for s in sizes[:3]
        ])

        self.embeddings[0].weight.data *= init_size
        self.embeddings[1].weight.data *= init_size
        self.embeddings[2].weight.data *= init_size
        self.embeddings1[0].weight.data *= init_size
        self.embeddings_c[1].weight.data *= init_size
        
        self.lhs = self.embeddings[0]
        self.lhs1 = self.embeddings2[0]
        self.lhs2 = self.embeddings3[0]        
        self.rel = self.embeddings[1]
        self.rhs = self.embeddings[2]
        self.trans=self.embeddings1[0]
        self.trans_ehs=self.embeddings1[1]
        self.rhs_rot = self.embeddings1[1]
        self.cur=self.embeddings_c[1]
    def forward(self, x):
        c1= F.softplus(self.cur(x[:,1])[1])
        c2= F.softplus(self.cur(x[:,1])[2])
        c3= F.softplus(self.cur(x[:,1])[3])        
        lhs = self.lhs(x[:, 0])
        lhs1 = self.lhs1(x[:, 0])
        lhs2 = self.lhs2(x[:, 0])
        rel = self.rel(x[:, 1])
        rel_rot=self.rhs_rot(x[:, 1])
        rhs = self.rhs(x[:, 2])
        trans,r1,r2,r3=torch.chunk(self.trans(x[:,1]), 4, dim=1)  
        t1,t2,t3,_=torch.chunk(self.trans_ehs(x[:,1]), 4, dim=1)  
        lhs_c2=expmap0(lhs1, c2);        lhs_c3=expmap0(lhs2, c3)
        lhs_1=givens_rotations(r1,lhs)
        lhs_2=multi_mx(lhs_c2,r2,c2);lhs_3=multi_mx(lhs_c3,r3,c3);
        lhs_2=logmap0(lhs_2,c2)  ;        lhs_3=logmap0(lhs_3,c3)    
        lhs_1=(lhs_1).view(-1, 1, self.rank);        lhs_2=(lhs_2).view(-1, 1, self.rank);  lhs_3=(lhs_3).view(-1, 1, self.rank);      
        cands = torch.cat([1*lhs_1, 1*lhs_2,1*lhs_3], dim=1)
        context_vec = self.context_vec(x[:, 1]).view((-1, 1, self.rank))
        att_weights = torch.sum(context_vec* cands * self.scale, dim=-1, keepdim=True)
        att_weights = self.act(att_weights)
        att_q = torch.sum(att_weights * cands, dim=1)
        return (att_q)@ self.rhs.weight.t(), [(lhs, rel, rhs)]
