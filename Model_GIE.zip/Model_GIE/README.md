## Environment
- Python 3.5+
- PyTorch 1.0+
- tqdm 4.41.1+

### Data Process
```shell script
cd code
python3 process_datasets.py
```

### Run
```shell script
CUDA_VISIBLE_DEVICES=7 python3 learn.py --dataset WN18RR --model KG_Model --rank 200 --optimizer Adagrad \
--learning_rate 1e-1 --batch_size 100 --regularizer Re --reg 1e-1 --max_epochs 200 \
--valid 5 -train -id 0 -save -weight
CUDA_VISIBLE_DEVICES=4 python3 learn.py --dataset FB237 --model KG_Model --rank 200 --optimizer Adagrad \
--learning_rate 1e-1 --batch_size 2000 --regularizer N3 --reg 5e-2 --max_epochs 200 \
--valid 5 -train -id 0 -save
CUDA_VISIBLE_DEVICES=0 python learn.py --dataset YAGO3-10 --model KG_Model --rank 200 --optimizer Adagrad \
--learning_rate 1e-1 --batch_size 100 --regularizer N3 --reg 5e-3 --max_epochs 200 \
--valid 5 -train -id 0 -save -weight
```

## Acknowledgement
We refer to the code of [kbc](https://github.com/facebookresearch/kbc). Thanks for their contributions.
